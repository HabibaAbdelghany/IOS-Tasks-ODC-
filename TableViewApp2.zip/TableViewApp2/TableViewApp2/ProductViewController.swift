//
//  ProductViewController.swift
//  TableViewApp2
//
//  Created by odc on 18/03/2023.
//

import UIKit

class ProductViewController: UIViewController {

    @IBOutlet weak var tabeViewProduct: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    



}
