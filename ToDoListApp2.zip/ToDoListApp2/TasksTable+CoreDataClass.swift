//
//  TasksTable+CoreDataClass.swift
//  ToDoListApp2
//
//  Created by odc on 01/04/2023.
//
//

import Foundation
import CoreData

@objc(TasksTable)
public class TasksTable: NSManagedObject {

}
