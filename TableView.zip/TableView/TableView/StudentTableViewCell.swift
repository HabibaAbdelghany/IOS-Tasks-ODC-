//
//  StudentTableViewCell.swift
//  TableView
//
//  Created by odc on 16/03/2023.
//

import UIKit

class StudentTableViewCell: UITableViewCell {


    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
