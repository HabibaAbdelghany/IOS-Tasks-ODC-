//
//  SliderCollectionViewCell.swift
//  CollectionApp
//
//  Created by odc on 21/03/2023.
//

import UIKit

class SliderCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgSlider: UIImageView!
}
