//
//  TaksTable+CoreDataClass.swift
//  ToDoList
//
//  Created by odc on 28/03/2023.
//
//

import Foundation
import CoreData

@objc(TaksTable)
public class TaksTable: NSManagedObject {

}
